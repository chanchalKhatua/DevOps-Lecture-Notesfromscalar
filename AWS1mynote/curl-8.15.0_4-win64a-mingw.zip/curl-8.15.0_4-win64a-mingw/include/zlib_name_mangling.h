/* zlib_name_mangling.h has been automatically generated from
 * zlib_name_mangling.h.empty because ZLIB_SYMBOL_PREFIX was NOT set.
 */

#ifndef ZLIB_NAME_MANGLING_H
#define ZLIB_NAME_MANGLING_H

#endif /* ZLIB_NAME_MANGLING_H */
